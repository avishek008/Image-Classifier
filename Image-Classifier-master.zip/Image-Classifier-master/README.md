# Image-Classifier

How would you like to snap a picture of a flower and know instantly what flower it actually is without having to search for hours on end?

This application will use a deep learning model to accurately predict the flower that you give it.
